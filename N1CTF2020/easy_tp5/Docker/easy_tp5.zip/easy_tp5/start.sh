#!/bin/bash

sleep 1

pkill apache2

chmod 700 /flag
chmod 700 /start.sh
chown -R root:root /var/www/html
chmod -R 755 /var/www/html
chmod 777 /var/www/html/public
chmod +s /usr/bin/tac

cp /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
sed -i 's/Options Indexes FollowSymLinks/Options None/' /etc/apache2/apache2.conf
sed -i 's/AllowOverride None/AllowOverride All/' /etc/apache2/apache2.conf
sed -i 's/combined/#combined/' /etc/apache2/apache2.conf
echo 'LogFormat "%h %l %u %t \"%r\" %>s" combined' >> /etc/apache2/apache2.conf
cat /default.conf > /etc/apache2/sites-enabled/000-default.conf
rm -rf /default.conf

mv /etc/modsecurity/modsecurity.conf-recommended /etc/modsecurity/modsecurity.conf
sed -i 's/ABDEFHIJZ/ABC/' /etc/modsecurity/modsecurity.conf
echo "SecAuditLog /var/log/apache2/modsec_audit.log" >> /etc/modsecurity/modsecurity.conf
    
rm -rf /start.sh
service apache2 start
tail -F /var/log/apache2/access.log
